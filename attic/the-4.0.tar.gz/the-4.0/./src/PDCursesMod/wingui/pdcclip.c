/* PDCurses */

#include "pdcwin.h"
#include <string.h>

#include "../common/winclip.c"
